
    <div class="course__categories ">
    <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
    </div>
