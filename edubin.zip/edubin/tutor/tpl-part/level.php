
<div class="course__level">
   <?php echo '<span class="tutor-course-loop-level">' . get_tutor_course_level() . '</span>';?>
</div>
