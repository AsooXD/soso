
<?php if ( function_exists( 'ldcr_course_rating_stars' ) ) { 
      ldcr_course_rating_stars();
   }
?> 