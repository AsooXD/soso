
<div class="course__level">
   <span>Beginner</span>
</div>
