
  <h4 class="course__title"> <a href="<?php the_permalink(); ?>" class="course__title-link"> <?php the_title(); ?> </a></h4>