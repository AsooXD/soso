<p class="course__excerpt">
    <?php echo wp_kses_post( get_the_excerpt() ); ?>
</p>